// popup.js — Price Tracker Extension (Firefox MV2)

const $ = (id) => document.getElementById(id);
let config = { chatId: "", apiBase: "" };

// --- Init ---
document.addEventListener("DOMContentLoaded", async () => {
  try {
    config = await getConfig();
    if (!config.chatId || !config.apiBase) {
      showScreen("setup-screen");
      if (config.apiBase) $("api-url-input").value = config.apiBase;
      if (config.chatId) $("chat-id-input").value = config.chatId;
    } else {
      showScreen("main-screen");
      autoFillCurrentTab();
      loadProducts();
    }
  } catch (e) {
    // Fallback: always show setup screen if anything fails
    showScreen("setup-screen");
  }

  bindEvents();
});

// --- Screen / Tab helpers ---
function showScreen(id) {
  document.querySelectorAll(".screen").forEach((s) => s.classList.add("hidden"));
  $(id).classList.remove("hidden");
}

function showTab(name) {
  document.querySelectorAll(".tab").forEach((t) =>
    t.classList.toggle("active", t.dataset.tab === name)
  );
  document.querySelectorAll(".tab-content").forEach((c) => c.classList.add("hidden"));
  $("tab-" + name).classList.remove("hidden");
  if (name === "list") loadProducts();
}

// --- Storage — Firefox uses Promise-based browser.storage ---
async function getConfig() {
  const data = await browser.storage.local.get(["chatId", "apiBase"]);
  return { chatId: data.chatId || "", apiBase: data.apiBase || "" };
}

async function saveConfig(chatId, apiBase) {
  await browser.storage.local.set({ chatId, apiBase });
}

// --- Auto-fill URL ---
async function autoFillCurrentTab() {
  try {
    const data = await browser.storage.local.get(["pendingUrl"]);
    if (data.pendingUrl) {
      $("product-url").value = data.pendingUrl;
      await browser.storage.local.remove("pendingUrl");
      showTab("track");
      return;
    }
    const tabs = await browser.tabs.query({ active: true, currentWindow: true });
    const tab = tabs && tabs[0];
    if (tab && tab.url && (tab.url.includes("amazon.") || tab.url.includes("flipkart.com"))) {
      $("product-url").value = tab.url;
    }
  } catch (e) {
    // non-critical, ignore
  }
}

// --- Bind Events ---
function bindEvents() {
  $("save-setup-btn").addEventListener("click", async () => {
    const chatId = $("chat-id-input").value.trim();
    const apiBase = $("api-url-input").value.trim().replace(/\/$/, "");
    if (!chatId || !apiBase) { showToast("Please fill in both fields."); return; }
    await saveConfig(chatId, apiBase);
    config = { chatId, apiBase };
    showScreen("main-screen");
    autoFillCurrentTab();
    loadProducts();
  });

  $("settings-btn").addEventListener("click", () => {
    showScreen("setup-screen");
    $("chat-id-input").value = config.chatId;
    $("api-url-input").value = config.apiBase;
  });

  document.querySelectorAll(".tab").forEach((btn) => {
    btn.addEventListener("click", () => showTab(btn.dataset.tab));
  });

  $("track-btn").addEventListener("click", trackProduct);
  $("product-url").addEventListener("keydown", (e) => {
    if (e.key === "Enter") trackProduct();
  });

  $("refresh-btn").addEventListener("click", loadProducts);
}

// --- Track Product ---
async function trackProduct() {
  const url = $("product-url").value.trim();
  if (!url) { showToast("Paste a product URL first."); return; }
  if (!url.startsWith("http")) { showToast("Invalid URL."); return; }

  setTracking(true);
  $("track-result").classList.add("hidden");

  try {
    const resp = await fetch(config.apiBase + "/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: url, chat_id: config.chatId }),
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.detail || "Failed to track.");

    const siteLabel = { amazon: "🛒 Amazon", flipkart: "🛍️ Flipkart" }[data.site] || "🏪 " + data.site;
    const card = $("track-result");
    card.innerHTML =
      "<div class='product-title'>" + escHtml(data.title) + "</div>" +
      "<div class='product-price'>₹" + Number(data.price).toLocaleString("en-IN") + "</div>" +
      "<div class='product-site'>" + siteLabel + "</div>";
    card.classList.remove("hidden", "error");
    showToast("✅ Added!");
    $("product-url").value = "";
  } catch (err) {
    const card = $("track-result");
    card.innerHTML = "<div class='error-msg'>❌ " + escHtml(err.message) + "</div>";
    card.classList.remove("hidden");
    card.classList.add("error");
  } finally {
    setTracking(false);
  }
}

function setTracking(on) {
  $("track-btn").disabled = on;
  $("track-btn-text").textContent = on ? "Fetching..." : "Track Price";
  $("track-spinner").classList.toggle("hidden", !on);
}

// --- Products List ---
async function loadProducts() {
  const listEl = $("products-list");
  const emptyEl = $("products-empty");
  const loadingEl = $("products-loading");

  listEl.innerHTML = "";
  emptyEl.classList.add("hidden");
  loadingEl.classList.remove("hidden");

  try {
    const resp = await fetch(config.apiBase + "/products/" + encodeURIComponent(config.chatId));
    if (!resp.ok) throw new Error("API error");
    const products = await resp.json();
    loadingEl.classList.add("hidden");

    if (!products.length) {
      emptyEl.classList.remove("hidden");
      return;
    }
    products.forEach((p) => listEl.appendChild(buildCard(p)));
  } catch (e) {
    loadingEl.classList.add("hidden");
    listEl.innerHTML = "<p style='color:#dc3545;font-size:13px;padding:8px 0'>Could not load. Check backend URL in settings.</p>";
  }
}

function buildCard(p) {
  const div = document.createElement("div");
  div.className = "product-item";
  const emoji = { amazon: "🛒", flipkart: "🛍️" }[p.site] || "🏪";
  const price = "₹" + Number(p.current_price).toLocaleString("en-IN");
  const strikethrough = (p.initial_price && p.initial_price !== p.current_price)
    ? " <span class='initial-price'>₹" + Number(p.initial_price).toLocaleString("en-IN") + "</span>"
    : "";

  div.innerHTML =
    (p.image_url ? "<img class='thumb' src='" + escHtml(p.image_url) + "' alt='' onerror=\"this.style.display='none'\" />" : "") +
    "<div class='info'>" +
      "<div class='name' title='" + escHtml(p.title) + "'>" + escHtml(p.title) + "</div>" +
      "<div class='price'>" + price + strikethrough + "</div>" +
      "<div class='meta'>" + emoji + " " + escHtml(p.site) + " &nbsp;•&nbsp; ID: " + p.id + "</div>" +
    "</div>" +
    "<button class='remove-btn' title='Remove'>🗑</button>";

  div.querySelector(".remove-btn").addEventListener("click", () => removeProduct(p.id, div));
  return div;
}

async function removeProduct(id, el) {
  el.style.opacity = "0.5";
  try {
    const resp = await fetch(config.apiBase + "/products/" + id, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: config.chatId }),
    });
    if (!resp.ok) throw new Error();
    el.remove();
    showToast("🗑 Removed");
    if (!$("products-list").children.length) {
      $("products-empty").classList.remove("hidden");
    }
  } catch {
    el.style.opacity = "1";
    showToast("Could not remove. Try again.");
  }
}

// --- Toast ---
function showToast(msg) {
  let t = document.querySelector(".toast");
  if (!t) {
    t = document.createElement("div");
    t.className = "toast";
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 2500);
}

function escHtml(s) {
  return String(s || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
